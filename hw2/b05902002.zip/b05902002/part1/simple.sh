#!/bin/bash
python3.6 -m BCN.predict model/submission 9
