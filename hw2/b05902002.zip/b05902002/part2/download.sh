#!/bin/bash
wget https://www.dropbox.com/s/gmz8wlpww9ykly8/model.zip?dl=1
unzip model.zip?dl=1
